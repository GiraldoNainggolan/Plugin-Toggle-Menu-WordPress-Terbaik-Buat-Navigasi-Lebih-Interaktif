﻿=== GutenTOC - Advance Table of Content for Gutenberg ===
Contributors: Tauhidpro
Tags:  table of contents, toc, anchors, advance table of contents
Donate link: http://tauhidpro.com/contact/
Requires at least: 5.2
Tested up to: 6.5
Requires PHP: 5.6
Stable tag: 2.0.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

GutenTOC is Satisfaction guaranteed TOC builder If you use Gutenberg editor and need to create table of content any place.

== Description ==
GutenTOC plugin is SEO-friendly customizable Gutenberg block editor which scans headings through the Page or Post content and creates the table of contents(TOC) automatically.

= SUPPORTING FUTURE DEVELOPMENT =
If you like this plugin, please rate and review it here in the WordPress Plugin Directory or support it with good review. Thank you!

## How to add a block 
Goto Gutenberg page Editor, add a block by search for “toc” or “table of contents”. 

## Featured

* Automatically generate a table of contents by insert Advance Table of Content block.
* Automatically generates anchor, but you will be able to customize if you want.
* SEO friendly table of Contents and anchor so it will display nicely in search result page (SERP).
* You can change toggle.
* Counter bullet formats are none, decimal, numeric, iconic.
* Smooth scrolling when click anchor.

== Installation ==

= To install the plugin automatically: =
* You'll need WordPress version 5.0 or higher for this to work.
* Require Gutenberg Editor**
* Through WordPress admin, use the menu: Plugin > Add new
* Click on install then click activate link
* In page or post Search for a block : toc or find it under Common Blocks category

== Screenshots ==

1. TOC Initially Hide 
2. TOC in Editor
3. TOC Position Right
4. TOC Left Right 
5. TOC Background Color
6. TOC Border Color
7. TOC Text Color
8. Toc Border Radius

== Frequently Asked Questions ==

= Can I get support for the editor use? =
We reply to every question about the editor on the forum here, just ask :) 

= Does Plugin slowing down my website? =
The plugin has almost NO impact on page load for your visitors, it's only loaded during the edition process.

= Is plugins free? =
Yes, totally free of charge.


== Upgrade Notice ==

Update through the automatic WordPress updater, all Advanced Gutenberg content and configuration will remain in place.

== Changelog ==

= 0.0.1 =
* Initial Release.
= 0.0.2 =
* Add- Toc Alignment

= 1.0.1 =
*  wp 5.5 compatible

= 2.0.1 =
*  Find Extra Editor Core CSS

= 2.0.2 =
*  Find Scrooling Issue
= 2.0.2 =
*  Find Extra Editor Core CSS again
= 2.0.5 =
*  Add options, Font Size, Line Height, Font weight, Font Family,Letter Spacing,Text Color,Text Hover Color,
Hover Undeline
