<?php
/**
 *
 * @since      2.5
 *
 * @package    Accordion & FAQs
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}