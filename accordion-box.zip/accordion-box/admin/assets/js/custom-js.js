jQuery(document).ready( function () {
  jQuery(".lined").linedtextarea({
	    selectedLine: 10
	  });
});