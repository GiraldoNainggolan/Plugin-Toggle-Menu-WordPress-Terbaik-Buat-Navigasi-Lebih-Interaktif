<style>
	#tabs_r_help{
	background:#fff;
	display:block;
	width:100%;
	
	margin-top:40px;
	
	}
	#tabs_r_help .hndle , #tabs_r_help .handlediv{
	display:none;
	}
	#tabs_r_help p{
	color:#000;
	font-size:15px;
	}
	#tabs_r_help .inside{
		margin:0px !important;
		padding:0px !important;
	}
.wpsm_ac_h_i2{
			   
		
			padding-top:20px;
			padding-bottom:20px;
			padding-left:20px;
			    overflow: HIDDEN;
			color:#fff;
		}
		.wpsm_ac_h_i2 .btn-danger{
			font-size: 29px;
			background-color: #000000;
			border-radius:1px;
			margin-right:10px;
			
			border-color:#000;
			margin-top:20px;
			 
		}
		.wpsm_ac_h_i2 .btn-success{
			font-size: 28px;
			border-radius:1px;
			background-color: #e2e2e2;
			border-color: #ffffff;
			color:#000;
			margin-top:20px;
		}
		.wpsm_ac_h_i2 a {
    text-decoration: none;
}
</style>


<div class="wpsm_ac_h_i2 " >
	<h1 style="color:#000;"><?php esc_html_e('Get Support Help Here',wpshopmart_accordion_text_domain); ?></h1>
	<h3 style="color:#000;"><?php esc_html_e('If You have any issue then please ask us any time',wpshopmart_accordion_text_domain); ?></h3>
	<a href="https://wordpress.org/support/plugin/responsive-accordion-and-collapse" target="_blank" class="button button-primary button-hero "><?php esc_html_e('Get Support Here',wpshopmart_accordion_text_domain); ?></a>
	</br></br>
	<div>							
		<h1 style="color:#000;font-size:24px;font-weight:500;line-height:1.4"><?php esc_html_e('Accordion documentation',wpshopmart_accordion_text_domain); ?></h1>				
	</div>	

				<div class="row">			
	</br></br>
	<div class="col-md-12" >	
	<iframe width="600" height="370" src="https://www.youtube.com/embed/iu2Wj7qZo_g" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	</div>
	</div>
	<div class="row">
		<div class="row col-md-12" style="margin-bottom: 30px;">
			<div class="col-md-4">	<img width="100" height="20" style="width:310px;height:auto; margin-top: 20px;" src="<?php echo esc_url(wpshopmart_accordion_directory_url.'img/wpshopmart-logo.png'); ?>" > </div>
			</br></br>
			<div class="col-md-12"><a class="btn btn-danger btn-lg " href="https://www.youtube.com/c/wpshopmart?sub_confirmation=1" target="_blank"><?php esc_html_e('Subscribe Our Channel',wpshopmart_accordion_text_domain); ?></a>
			<a class="btn btn-success btn-lg " href="https://www.youtube.com/c/wpshopmart" target="_blank"><?php esc_html_e('Check More Helping Videos',wpshopmart_accordion_text_domain); ?></a></div>
		</div>	
	</div>	
</div>
						